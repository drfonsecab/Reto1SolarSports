package com.example.solarsportsreto1;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BeneficiosActivity extends AppCompatActivity {

    private TextView beneficiosTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beneficios);

        beneficiosTextView = findViewById(R.id.textView_beneficios);

        // Aquí se pueden calcular y mostrar los beneficios
    }
}

