package com.example.solarsportsreto1;

import java.util.ArrayList;

public class Beneficios {
    public static String generarRecomendacion(ArrayList<TerrazaSolar> terrazas) {
        double totalAhorro = 0;
        for (TerrazaSolar terraza : terrazas) {
            totalAhorro += terraza.getValorAhorrado();
        }

        return "Se han ahorrado " + totalAhorro + " en el último periodo.";
    }
}

