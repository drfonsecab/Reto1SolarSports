package com.example.solarsportsreto1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegistroActivity extends AppCompatActivity {

    private EditText energiaProducidaEditText;
    private EditText valorAhorradoEditText;
    private EditText mesEditText;
    private Button registrarButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        energiaProducidaEditText = findViewById(R.id.editText_energiaProducida);
        valorAhorradoEditText = findViewById(R.id.editText_valorAhorrado);
        mesEditText = findViewById(R.id.editText_mes);
        registrarButton = findViewById(R.id.button_registrar);

        registrarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aquí se puede agregar la lógica para registrar los datos
                Toast.makeText(RegistroActivity.this, "Datos registrados correctamente", Toast.LENGTH_SHORT).show();
            }
        });
    }
}