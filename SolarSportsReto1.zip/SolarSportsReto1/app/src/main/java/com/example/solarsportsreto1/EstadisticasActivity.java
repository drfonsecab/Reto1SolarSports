package com.example.solarsportsreto1;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EstadisticasActivity extends AppCompatActivity {

    private TextView promedioTextView;
    private TextView maximoTextView;
    private TextView minimoTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);

        promedioTextView = findViewById(R.id.textView_promedio);
        maximoTextView = findViewById(R.id.textView_maximo);
        minimoTextView = findViewById(R.id.textView_minimo);

        // Aquí se pueden calcular y mostrar las estadísticas
    }
}

