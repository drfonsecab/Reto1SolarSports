package com.example.solarsportsreto1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegistroActivity extends AppCompatActivity {

    private EditText energyProducedEditText;
    private EditText savingsEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        energyProducedEditText = findViewById(R.id.editText_energy_produced);
        savingsEditText = findViewById(R.id.editText_savings);
        saveButton = findViewById(R.id.button_save);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });
    }

    private void saveData() {
        String energyProducedStr = energyProducedEditText.getText().toString();
        String savingsStr = savingsEditText.getText().toString();

        if (energyProducedStr.isEmpty() || savingsStr.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese todos los datos", Toast.LENGTH_SHORT).show();
            return;
        }

        double energyProduced = Double.parseDouble(energyProducedStr);
        double savings = Double.parseDouble(savingsStr);

        // Guardar los valores en los arrays de la clase MainActivity
        MainActivity.energiasProducidas.add(energyProduced);
        MainActivity.ahorrosEnergeticos.add(savings);

        // Limpiar los campos de texto
        energyProducedEditText.setText("");
        savingsEditText.setText("");

        Toast.makeText(this, "Datos guardados exitosamente", Toast.LENGTH_SHORT).show();
    }
}