package com.example.solarsportsreto1;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EstadisticasActivity extends AppCompatActivity {

    private TextView averageTextView;
    private TextView maxTextView;
    private TextView minTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);

        averageTextView = findViewById(R.id.textView_average);
        maxTextView = findViewById(R.id.textView_max);
        minTextView = findViewById(R.id.textView_min);

        double average = calculateAverage();
        double max = calculateMax();
        double min = calculateMin();

        averageTextView.setText("Promedio de Energía Producida: " + average + " kWh");
        maxTextView.setText("Máxima Energía Producida: " + max + " kWh");
        minTextView.setText("Mínima Energía Producida: " + min + " kWh");
    }

    private double calculateAverage() {
        double sum = 0;
        for (double production : MainActivity.energiasProducidas) {
            sum += production;
        }
        return sum / MainActivity.energiasProducidas.size();
    }

    private double calculateMax() {
        double max = Double.MIN_VALUE;
        for (double production : MainActivity.energiasProducidas) {
            if (production > max) {
                max = production;
            }
        }
        return max;
    }

    private double calculateMin() {
        double min = Double.MAX_VALUE;
        for (double production : MainActivity.energiasProducidas) {
            if (production < min) {
                min = production;
            }
        }
        return min;
    }
}

