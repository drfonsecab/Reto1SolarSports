package com.example.solarsportsreto1;

import java.util.ArrayList;

public class Estadisticas {
    public static double calcularPromedio(ArrayList<TerrazaSolar> terrazas) {
        double suma = 0;
        for (TerrazaSolar terraza : terrazas) {
            suma += terraza.getEnergiaProducida();
        }
        return suma / terrazas.size();
    }

    public static double calcularMaximo(ArrayList<TerrazaSolar> terrazas) {
        double max = Double.MIN_VALUE;
        for (TerrazaSolar terraza : terrazas) {
            if (terraza.getEnergiaProducida() > max) {
                max = terraza.getEnergiaProducida();
            }
        }
        return max;
    }

    public static double calcularMinimo(ArrayList<TerrazaSolar> terrazas) {
        double min = Double.MAX_VALUE;
        for (TerrazaSolar terraza : terrazas) {
            if (terraza.getEnergiaProducida() < min) {
                min = terraza.getEnergiaProducida();
            }
        }
        return min;
    }
}

