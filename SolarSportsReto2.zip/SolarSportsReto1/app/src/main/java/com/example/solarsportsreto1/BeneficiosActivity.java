package com.example.solarsportsreto1;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class BeneficiosActivity extends AppCompatActivity {

    private TextView totalSavingsTextView;
    private TextView recommendationTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beneficios);

        totalSavingsTextView = findViewById(R.id.textView_total_savings);
        recommendationTextView = findViewById(R.id.textView_recommendation);

        double totalSavings = calculateTotalSavings();
        String recommendation = generateRecommendation(totalSavings);

        totalSavingsTextView.setText("Ahorros Económicos Totales: $" + totalSavings);
        recommendationTextView.setText("Recomendación: " + recommendation);
    }

    private double calculateTotalSavings() {
        double total = 0;
        for (double savings : MainActivity.ahorrosEnergeticos) {
            total += savings;
        }
        return total;
    }

    private String generateRecommendation(double totalSavings) {
        if (totalSavings > 10000) {
            return "¡Excelente trabajo! Considera invertir en más terrazas solares para maximizar tus ahorros.";
        } else if (totalSavings > 5000) {
            return "Vas por buen camino. ¡Sigue monitoreando y aumentando tu eficiencia energética!";
        } else {
            return "Podrías considerar mejorar la eficiencia de tus instalaciones o expandir el uso de terrazas solares.";
        }
    }
}

