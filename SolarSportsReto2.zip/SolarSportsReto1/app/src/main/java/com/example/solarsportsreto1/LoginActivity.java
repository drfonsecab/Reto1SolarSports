package com.example.solarsportsreto1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;

    // Arrays para almacenar los datos de los usuarios
    private static String[] usuarios = new String[10];
    private static String[] contraseñas = new String[10];
    private static String[] nombres = new String[10];
    private static String[] correos = new String[10];
    private static int contadorUsuarios = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        registerButton = findViewById(R.id.register_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (authenticate(username, password)) {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean authenticate(String username, String password) {
        for (int i = 0; i < contadorUsuarios; i++) {
            if (usuarios[i].equals(username) && contraseñas[i].equals(password)) {
                return true;
            }
        }
        return false;
    }

    public static void registerUser(String nombre, String correo, String usuario, String contraseña) {
        if (contadorUsuarios < usuarios.length) {
            nombres[contadorUsuarios] = nombre;
            correos[contadorUsuarios] = correo;
            usuarios[contadorUsuarios] = usuario;
            contraseñas[contadorUsuarios] = contraseña;
            contadorUsuarios++;
        }
    }
}
