package com.example.solarsportsreto1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class CategoriasActivity extends AppCompatActivity {

    private Button microfutbolButton;
    private Button gimnasioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorias);

        microfutbolButton = findViewById(R.id.button_microfutbol);
        gimnasioButton = findViewById(R.id.button_gimnasio);

        microfutbolButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriasActivity.this, RegistroActivity.class);
                intent.putExtra("categoria", "Microfútbol");
                startActivity(intent);
            }
        });

        gimnasioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoriasActivity.this, RegistroActivity.class);
                intent.putExtra("categoria", "Gimnasio");
                startActivity(intent);
            }
        });
    }
}