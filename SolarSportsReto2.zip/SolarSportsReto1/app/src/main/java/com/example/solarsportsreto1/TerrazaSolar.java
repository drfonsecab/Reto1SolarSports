package com.example.solarsportsreto1;

public class TerrazaSolar {
    private Categoria categoria;
    private double energiaProducida;
    private double valorAhorrado;
    private String mes;

    public TerrazaSolar(Categoria categoria, double energiaProducida, double valorAhorrado, String mes) {
        this.categoria = categoria;
        this.energiaProducida = energiaProducida;
        this.valorAhorrado = valorAhorrado;
        this.mes = mes;
    }

    // Getters y Setters


    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public double getEnergiaProducida() {
        return energiaProducida;
    }

    public void setEnergiaProducida(double energiaProducida) {
        this.energiaProducida = energiaProducida;
    }

    public double getValorAhorrado() {
        return valorAhorrado;
    }

    public void setValorAhorrado(double valorAhorrado) {
        this.valorAhorrado = valorAhorrado;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }
}
